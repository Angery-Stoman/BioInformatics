Team of 3:
Munteanu Amalia-Nicole
Francu Teodor-Matei
Radu Matei


