import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

class DNAAligner:
    def __init__(self, seq1, seq2, match_reward=1, mismatch_penalty=-1, gap_penalty=-1):
        self.seq1 = seq1
        self.seq2 = seq2
        self.match_reward = match_reward
        self.mismatch_penalty = mismatch_penalty
        self.gap_penalty = gap_penalty
        
        self.n = len(seq1)
        self.m = len(seq2)
        
        # Initialize the score matrix
        self.score_matrix = np.zeros((self.n + 1, self.m + 1))
        # Initialize direction matrix (for traceback logic)
        # 0: done, 1: diagonal (match/mismatch), 2: up (gap in seq2), 3: left (gap in seq1)
        self.direction_matrix = np.zeros((self.n + 1, self.m + 1), dtype=int) 

        self.aligned_seq1 = ""
        self.aligned_seq2 = ""
        self.matches = 0
        self.similarity = 0.0

    def compute_matrix(self):
        # Initialization (Base cases)
        for i in range(1, self.n + 1):
            self.score_matrix[i][0] = i * self.gap_penalty
            self.direction_matrix[i][0] = 2
        for j in range(1, self.m + 1):
            self.score_matrix[0][j] = j * self.gap_penalty
            self.direction_matrix[0][j] = 3

        # Fill matrix
        for i in range(1, self.n + 1):
            for j in range(1, self.m + 1):
                # Calculate scores
                if self.seq1[i-1] == self.seq2[j-1]:
                    score_diag = self.score_matrix[i-1][j-1] + self.match_reward
                else:
                    score_diag = self.score_matrix[i-1][j-1] + self.mismatch_penalty
                
                score_up = self.score_matrix[i-1][j] + self.gap_penalty
                score_left = self.score_matrix[i][j-1] + self.gap_penalty
                
                # Take the max
                max_score = max(score_diag, score_up, score_left)
                self.score_matrix[i][j] = max_score
                
                # Store direction (priority to Diagonal)
                if max_score == score_diag:
                    self.direction_matrix[i][j] = 1
                elif max_score == score_up:
                    self.direction_matrix[i][j] = 2 # Up
                else:
                    self.direction_matrix[i][j] = 3 # Left

    def traceback(self):
        i, j = self.n, self.m
        path_coords = [] # Store coordinates for plotting later
        
        while i > 0 or j > 0:
            path_coords.append((j, i)) # Note: (x, y) for plotting is (col, row)
            
            if i > 0 and j > 0 and self.direction_matrix[i][j] == 1:
                # Diagonal (Match or Mismatch)
                self.aligned_seq1 = self.seq1[i-1] + self.aligned_seq1
                self.aligned_seq2 = self.seq2[j-1] + self.aligned_seq2
                i -= 1
                j -= 1
            elif i > 0 and (self.direction_matrix[i][j] == 2 or j == 0):
                # Up (Gap in Seq2)
                self.aligned_seq1 = self.seq1[i-1] + self.aligned_seq1
                self.aligned_seq2 = "-" + self.aligned_seq2
                i -= 1
            elif j > 0 and (self.direction_matrix[i][j] == 3 or i == 0):
                # Left (Gap in Seq1)
                self.aligned_seq1 = "-" + self.aligned_seq1
                self.aligned_seq2 = self.seq2[j-1] + self.aligned_seq2
                j -= 1
        
        path_coords.append((0, 0))
        return path_coords

    def calculate_statistics(self):
        self.matches = 0
        for k in range(len(self.aligned_seq1)):
            if self.aligned_seq1[k] == self.aligned_seq2[k]:
                self.matches += 1
        
        total_len = len(self.aligned_seq1)
        if total_len > 0:
            self.similarity = (self.matches / total_len) * 100
        else:
            self.similarity = 0

    def visualize(self, path_coords):
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        
        # --- Plot 1: Heatmap (Left Side of your image) ---
        # We flip the matrix vertically for display so (0,0) is top-left in image coords
        im1 = axes[0].imshow(self.score_matrix, cmap='magma', interpolation='nearest')
        axes[0].set_title("Alignment Matrix Heatmap")
        axes[0].set_xlabel("Sequence 2 Index")
        axes[0].set_ylabel("Sequence 1 Index")
        plt.colorbar(im1, ax=axes[0])

        # --- Plot 2: Traceback Grid (Right Side of your image) ---
        # Create a blank grid
        grid_display = np.zeros_like(self.score_matrix)
        axes[1].imshow(grid_display, cmap='YlGn', interpolation='nearest', alpha=0.1)
        
        # Add grid lines
        axes[1].set_xticks(np.arange(-.5, self.m, 1), minor=True)
        axes[1].set_yticks(np.arange(-.5, self.n, 1), minor=True)
        axes[1].grid(which='minor', color='black', linestyle='-', linewidth=1)
        axes[1].tick_params(which='minor', size=0) 

        # Highlight the path
        # Note: path_coords are (x, y) = (j, i)
        for (x, y) in path_coords:
            # Add a red rectangle for the path
            rect = patches.Rectangle((x - 0.5, y - 0.5), 1, 1, linewidth=1, edgecolor='r', facecolor='red')
            axes[1].add_patch(rect)

        axes[1].set_title("Traceback Path Deviation")
        axes[1].set_xlabel("Sequence 2")
        axes[1].set_ylabel("Sequence 1")
        
        # Set limits and invert Y axis to match matrix coordinates
        axes[1].set_xlim(-0.5, self.m + 0.5)
        axes[1].set_ylim(self.n + 0.5, -0.5)

        plt.tight_layout()
        plt.show()

    def print_results(self):
        print("-" * 30)
        print("ALIGNMENT RESULTS")
        print("-" * 30)
        print(f"Sequence 1: {self.aligned_seq1}")
        
        # Visual connector lines
        connectors = ""
        for k in range(len(self.aligned_seq1)):
            if self.aligned_seq1[k] == self.aligned_seq2[k]:
                connectors += "|"
            else:
                connectors += " "
        print(f"            {connectors}")
        print(f"Sequence 2: {self.aligned_seq2}")
        print("-" * 30)
        print(f"Matches    = {self.matches}")
        print(f"Length     = {len(self.aligned_seq1)}")
        print(f"Similarity = {self.similarity:.2f} %")
        print("-" * 30)

# --- Main Execution ---
if __name__ == "__main__":
    # Inputs from the image
    S1 = "ACCGTGAAGCCAATAC"
    S2 = "AGCGTGCAGCCAATAC"
    
    # Parameters (Standard Needleman-Wunsch settings)
    # Note: The image uses Gap=0, Match=1, Mismatch=-1. 
    # I used Gap=-1 here because usually Gap=0 results in poor alignments,
    # but you can change gap_penalty to 0 to match the image exactly.
    aligner = DNAAligner(S1, S2, match_reward=1, mismatch_penalty=-1, gap_penalty=-1)
    
    # Run
    aligner.compute_matrix()
    path = aligner.traceback()
    aligner.calculate_statistics()
    
    # Output Text
    aligner.print_results()
    
    # Output Graphics
    aligner.visualize(path)