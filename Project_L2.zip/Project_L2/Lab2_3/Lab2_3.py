#!/usr/bin/env python3
import tkinter as tk
from tkinter import filedialog, messagebox
import os
from typing import List, Dict
import matplotlib.pyplot as plt
import numpy as np

def read_fasta_sequence(path: str) -> str:
    seq_parts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                continue
            seq_parts.append(line)
    return "".join(seq_parts).upper()

def infer_alphabet(seq: str) -> List[str]:
    allowed_dna = set("ACGTN")
    obs = set(ch for ch in seq if ch.isalpha())
    if obs and obs.issubset(allowed_dna):
        return ["A", "C", "G", "T"]
    return sorted(obs)

def sliding_window_freqs(seq: str, k: int, alphabet: List[str]) -> Dict[str, List[float]]:
    L = len(seq)
    if k <= 0:
        raise ValueError("Window size k must be > 0")
    if L < k:
        return {sym: [] for sym in alphabet}
    alpha_set = set(alphabet)
    series = {sym: [] for sym in alphabet}
    counts = {sym: 0 for sym in alphabet}
    for i in range(k):
        ch = seq[i]
        if ch in alpha_set:
            counts[ch] += 1
    def to_percentages(counts_dict):
        return {sym: (counts_dict[sym] / k * 100.0) for sym in alphabet}
    first_pct = to_percentages(counts)
    for sym in alphabet:
        series[sym].append(first_pct[sym])
    for start in range(1, L - k + 1):
        old_char = seq[start - 1]
        new_char = seq[start + k - 1]
        if old_char in alpha_set:
            counts[old_char] -= 1
        if new_char in alpha_set:
            counts[new_char] += 1
        pcts = to_percentages(counts)
        for sym in alphabet:
            series[sym].append(pcts[sym])
    return series

def smooth_series(series: Dict[str, List[float]], window: int) -> Dict[str, List[float]]:
    if window <= 1:
        return series
    kernel = np.ones(window, dtype=float) / window
    smoothed = {}
    for sym, y in series.items():
        if len(y) == 0:
            smoothed[sym] = y
        else:
            smoothed[sym] = np.convolve(np.asarray(y, dtype=float), kernel, mode="same").tolist()
    return smoothed

def window_positions(L: int, k: int, mode: str = "start") -> List[int]:
    if L < k:
        return []
    n = L - k + 1
    if mode == "start":
        return list(range(1, n + 1))
    elif mode == "mid":
        return [start + (k // 2) for start in range(1, n + 1)]
    else:
        return list(range(1, n + 1))

def cumulative_percentages(seq: str, alphabet: List[str]):
    L = len(seq)
    cum_counts = {sym: 0 for sym in alphabet}
    xs = list(range(1, L + 1))
    series = {sym: [] for sym in alphabet}
    for i, ch in enumerate(seq, start=1):
        if ch in cum_counts:
            cum_counts[ch] += 1
        for sym in alphabet:
            series[sym].append(cum_counts[sym] / i * 100.0)
    return xs, series

def plot_series(series: Dict[str, List[float]], positions: List[int], title: str, xlabel: str):
    if not positions:
        messagebox.showwarning("No data", "No points to plot.")
        return
    plt.figure(figsize=(10, 5))
    for sym, y in series.items():
        plt.plot(positions, y, label=sym)
    plt.xlabel(xlabel)
    plt.ylabel("Relative frequency (%)")
    plt.title(title)
    plt.grid(True, alpha=0.3)
    plt.legend(title="Symbol")
    plt.tight_layout()
    plt.show()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Symbol Frequencies (Sliding or Cumulative)")
        self.geometry("600x300")
        self.resizable(False, False)
        self.file_path_var = tk.StringVar(value="")
        self.window_size_var = tk.StringVar(value="30")
        self.smooth_var = tk.StringVar(value="0")
        self.xmode_var = tk.StringVar(value="start")
        self.force_dna_var = tk.BooleanVar(value=True)
        self.mode_var = tk.StringVar(value="Cumulative")
        tk.Label(self, text="FASTA file:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        self.file_entry = tk.Entry(self, textvariable=self.file_path_var, width=48)
        self.file_entry.grid(row=0, column=1, padx=5, pady=10, sticky="w")
        tk.Button(self, text="Browse…", command=self.choose_file).grid(row=0, column=2, padx=10, pady=10)
        tk.Label(self, text="Mode:").grid(row=1, column=0, padx=10, pady=5, sticky="e")
        tk.OptionMenu(self, self.mode_var, "Cumulative", "Sliding").grid(row=1, column=1, padx=5, pady=5, sticky="w")
        tk.Label(self, text="Window size (k):").grid(row=2, column=0, padx=10, pady=5, sticky="e")
        self.window_entry = tk.Entry(self, textvariable=self.window_size_var, width=10)
        self.window_entry.grid(row=2, column=1, padx=5, pady=5, sticky="w")
        tk.Label(self, text="Smoothing (MA):").grid(row=3, column=0, padx=10, pady=5, sticky="e")
        self.smooth_entry = tk.Entry(self, textvariable=self.smooth_var, width=10)
        self.smooth_entry.grid(row=3, column=1, padx=5, pady=5, sticky="w")
        tk.Label(self, text="X-axis index:").grid(row=4, column=0, padx=10, pady=5, sticky="e")
        tk.OptionMenu(self, self.xmode_var, "start", "mid").grid(row=4, column=1, padx=5, pady=5, sticky="w")
        self.force_dna_check = tk.Checkbutton(self, text="Force DNA alphabet (A,C,G,T)", variable=self.force_dna_var)
        self.force_dna_check.grid(row=5, column=1, padx=5, pady=5, sticky="w")
        tk.Button(self, text="Analyze & Plot", command=self.run_analysis, width=20).grid(row=6, column=1, padx=5, pady=15, sticky="w")
        tk.Button(self, text="Quit", command=self.destroy, width=10).grid(row=6, column=2, padx=10, pady=15, sticky="e")
        self.status = tk.Label(self, text="", fg="#333")
        self.status.grid(row=7, column=0, columnspan=3, padx=10, pady=5, sticky="w")

    def choose_file(self):
        path = filedialog.askopenfilename(
            title="Choose a FASTA file",
            filetypes=[("FASTA files", "*.fasta *.fa *.fna *.ffn *.faa *.frn"), ("All files", "*.*")]
        )
        if path:
            self.file_path_var.set(path)

    def run_analysis(self):
        path = self.file_path_var.get().strip()
        if not path:
            messagebox.showerror("No file", "Please choose a FASTA file.")
            return
        if not os.path.exists(path):
            messagebox.showerror("File not found", f"Cannot find file:\n{path}")
            return
        try:
            k = int(self.window_size_var.get().strip())
            if k <= 0:
                raise ValueError
        except Exception:
            messagebox.showerror("Invalid window", "Window size must be a positive integer.")
            return
        try:
            seq = read_fasta_sequence(path)
        except Exception as e:
            messagebox.showerror("Read error", f"Failed to read FASTA:\n{e}")
            return
        if not seq:
            messagebox.showwarning("Empty sequence", "No sequence content found in the FASTA file.")
            return
        if self.force_dna_var.get():
            alphabet = ["A", "C", "G", "T"]
        else:
            alphabet = infer_alphabet(seq)
            if not alphabet:
                messagebox.showwarning("No alphabet", "Could not infer a valid alphabet from the sequence.")
                return
        mode = self.mode_var.get()
        try:
            smooth_w = int(self.smooth_var.get().strip())
            if smooth_w < 1:
                smooth_w = 1
        except Exception:
            smooth_w = 1
        if mode == "Cumulative":
            xs, series = cumulative_percentages(seq, alphabet)
            self.status.config(text=f"Sequence length: {len(seq)} | Points: {len(xs)} | Alphabet: {', '.join(alphabet)} | Mode: Cumulative")
            plot_series(series, xs, "Cumulative relative frequencies", "Sequence position")
        else:
            series = sliding_window_freqs(seq, k, alphabet)
            positions = window_positions(len(seq), k, mode=self.xmode_var.get())
            series_smoothed = smooth_series(series, smooth_w)
            self.status.config(text=f"Sequence length: {len(seq)} | Windows: {len(positions)} | Alphabet: {', '.join(alphabet)} | Mode: Sliding (MA={smooth_w})")
            title = f"Sliding-window {k} relative frequencies (MA={smooth_w})"
            plot_series(series_smoothed, positions, title, "Window position (start index)")

def main():
    app = App()
    app.mainloop()

if __name__ == "__main__":
    main()
