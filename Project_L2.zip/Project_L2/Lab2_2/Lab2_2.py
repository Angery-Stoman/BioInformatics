S = "abaabbcabcca"

# dinucleotides (k=2)
di_list = [''.join(p) for p in zip(S, S[1:])] #creates the list of overlapping dinucleotides
di_present = list(dict.fromkeys(di_list))   # checks only for the first appearance of dinucleotides

# trinucleotides (k=3)
tri_list = [''.join(p) for p in zip(S, S[1:], S[2:])] #same but for trinucleotides
tri_present = list(dict.fromkeys(tri_list)) #same but for trinucleotides...

print("dinucleotides present:", di_present)  #printing
print("trinucleotides present:", tri_present)  #printing again...
