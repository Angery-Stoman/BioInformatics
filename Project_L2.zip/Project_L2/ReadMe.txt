Team of 3:
Francu Teodor Matei
Radu Matei
Munteanu Amalia-Nicole